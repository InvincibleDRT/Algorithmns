"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 3:
(080) is the area code for fixed line telephones in Bangalore.
Fixed line numbers include parentheses, so Bangalore numbers
have the form (080)xxxxxxx.)

Part A: Find all of the area codes and mobile prefixes called by people
in Bangalore.
 - Fixed lines start with an area code enclosed in brackets. The area
   codes vary in length but always begin with 0.
 - Mobile numbers have no parentheses, but have a space in the middle
   of the number to help readability. The prefix of a mobile number
   is its first four digits, and they always start with 7, 8 or 9.
 - Telemarketers' numbers have no parentheses or space, but they start
   with the area code 140.

Print the answer as part of a message:
"The numbers called by people in Bangalore have codes:"
 <list of codes>
The list of codes should be print out one per line in lexicographic order with no duplicates.

Part B: What percentage of calls from fixed lines in Bangalore are made
to fixed lines also in Bangalore? In other words, of all the calls made
from a number starting with "(080)", what percentage of these calls
were made to a number also starting with "(080)"?

Print the answer as a part of a message::
"<percentage> percent of calls from fixed lines in Bangalore are calls
to other fixed lines in Bangalore."
The percentage should have 2 decimal digits
"""
def getPrefix(number):
  if number[0]=="(":
    return number[number.index('(')+1 :number.index(')')]
  if " " in number:
    return number[:3]
  if number[:2] =="140":
    return "140"

def isFixedLine(number):
  return number[0]=="("

def getPrefixByData(data,numbers):
  totalFixedCallMade=0
  totalFixedCallsToFixedCalls=0
  for i in data:
    n1 =getPrefix(i[0])
    if isFixedLine(i[0]) and isFixedLine(i[1]):
      totalFixedCallMade +=1
      totalFixedCallsToFixedCalls +=1
    elif isFixedLine(i[0]):
      totalFixedCallMade+=1

    n2 =getPrefix(i[1])

    if n1 != None:
      numbers.append(n1)
    if n2 != None:
      numbers.append(n2)
  return totalFixedCallMade,totalFixedCallsToFixedCalls

numbers =[]
a,b= getPrefixByData(calls,numbers)
x,y =getPrefixByData(texts,numbers)

print("The numbers called by people in Bangalore have codes:" )
print(sorted(list(set(numbers))))

print(str(round(float(a+x)/(b+y),2))+ " percent of calls from fixed lines in Bangalore are calls to other fixed lines in Bangalore.")